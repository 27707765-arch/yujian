// 遇见APP Service Worker - 提供离线缓存和类原生体验
const CACHE_NAME = 'yujian-v1';
const urlsToCache = [
  '/',
  '/index.html',
  '/manifest.json',
  '/icon.png'
];

// 安装：缓存核心资源
self.addEventListener('install', event => {
  event.waitUntil(
    caches.open(CACHE_NAME).then(cache => cache.addAll(urlsToCache))
  );
  self.skipWaiting();
});

// 激活：清理旧缓存
self.addEventListener('activate', event => {
  event.waitUntil(
    caches.keys().then(keys =>
      Promise.all(keys.filter(key => key !== CACHE_NAME).map(key => caches.delete(key)))
    )
  );
  self.clients.claim();
});

// 请求：缓存优先（API请求走网络）
self.addEventListener('fetch', event => {
  const url = new URL(event.request.url);
  // API 请求走网络，不缓存
  if (url.pathname.startsWith('/api/') || url.pathname === '/health') {
    return;
  }
  event.respondWith(
    caches.match(event.request).then(cached => cached || fetch(event.request))
  );
});
