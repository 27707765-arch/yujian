/**
 * 管理员控制器
 * 运营后台数据看板、用户管理
 */

const { executeQuery, isDbAvailable } = require('../utils/database');
const { success, error, serverError } = require('../utils/response');

/**
 * 安全获取查询结果首行
 * 防止 executeQuery 返回 null 时访问 [0] 导致 TypeError
 */
function safeFirst(result, defaultValue = {}) {
  if (!result || !Array.isArray(result) || result.length === 0) return defaultValue;
  return result[0] || defaultValue;
}

/**
 * 安全获取查询结果数组
 */
function safeRows(result) {
  if (!result || !Array.isArray(result)) return [];
  return result;
}

/**
 * 数据看板 - 核心指标
 */
async function getDashboard(req, res) {
  try {
    // 检查数据库可用性
    if (!isDbAvailable()) {
      return error(res, 503, '数据库服务不可用，请稍后重试');
    }

    const stats = {};

    // 用户总数
    stats.total_users = safeFirst(await executeQuery('SELECT COUNT(*) as total FROM users'), { total: 0 }).total;

    // 今日新增
    stats.today_new_users = safeFirst(
      await executeQuery('SELECT COUNT(*) as total FROM users WHERE DATE(created_at) = CURDATE()'),
      { total: 0 }
    ).total;

    // 活跃用户（今日有操作）
    stats.today_active_users = safeFirst(
      await executeQuery('SELECT COUNT(DISTINCT user_id) as total FROM likes WHERE DATE(created_at) = CURDATE()'),
      { total: 0 }
    ).total;

    // 匹配总数
    stats.total_matches = safeFirst(
      await executeQuery('SELECT COUNT(*) as total FROM matches WHERE status = 1'),
      { total: 0 }
    ).total;

    // 今日匹配
    stats.today_matches = safeFirst(
      await executeQuery('SELECT COUNT(*) as total FROM matches WHERE DATE(created_at) = CURDATE()'),
      { total: 0 }
    ).total;

    // 消息总数
    stats.total_messages = safeFirst(
      await executeQuery('SELECT COUNT(*) as total FROM messages'),
      { total: 0 }
    ).total;

    // 今日消息
    stats.today_messages = safeFirst(
      await executeQuery('SELECT COUNT(*) as total FROM messages WHERE DATE(created_at) = CURDATE()'),
      { total: 0 }
    ).total;

    // 今日礼物统计
    const giftResult = safeFirst(
      await executeQuery(
        'SELECT COUNT(*) as total, COALESCE(SUM(total_price), 0) as total_value FROM gift_records WHERE DATE(created_at) = CURDATE()'
      ),
      { total: 0, total_value: 0 }
    );
    stats.today_gifts = giftResult.total;
    stats.today_gift_value = giftResult.total_value;

    // 总付费
    stats.total_revenue = safeFirst(
      await executeQuery('SELECT COALESCE(SUM(amount), 0) as total FROM orders WHERE status = 1'),
      { total: 0 }
    ).total;

    // 今日付费
    stats.today_revenue = safeFirst(
      await executeQuery('SELECT COALESCE(SUM(amount), 0) as total FROM orders WHERE status = 1 AND DATE(created_at) = CURDATE()'),
      { total: 0 }
    ).total;

    // 举报待处理
    stats.pending_reports = safeFirst(
      await executeQuery('SELECT COUNT(*) as total FROM reports WHERE status = 0'),
      { total: 0 }
    ).total;

    success(res, stats);
  } catch (err) {
    serverError(res, err, '获取数据看板失败');
  }
}

/**
 * 用户列表（管理员视图）
 */
async function getUserList(req, res) {
  try {
    const { limit = 20, offset = 0, status, keyword } = req.query;
    let query = 'SELECT * FROM users WHERE 1=1';
    const params = [];

    if (status !== undefined) {
      query += ' AND status = ?';
      params.push(parseInt(status, 10));
    }
    if (keyword) {
      query += ' AND (nickname LIKE ? OR phone LIKE ?)';
      params.push(`%${keyword}%`, `%${keyword}%`);
    }
    query += ' ORDER BY created_at DESC LIMIT ? OFFSET ?';
    params.push(parseInt(limit, 10), parseInt(offset, 10));

    const users = safeRows(await executeQuery(query, params));

    // 总数
    let countQuery = 'SELECT COUNT(*) as total FROM users WHERE 1=1';
    const countParams = [];
    if (status !== undefined) {
      countQuery += ' AND status = ?';
      countParams.push(parseInt(status, 10));
    }
    if (keyword) {
      countQuery += ' AND (nickname LIKE ? OR phone LIKE ?)';
      countParams.push(`%${keyword}%`, `%${keyword}%`);
    }
    const total = safeFirst(await executeQuery(countQuery, countParams), { total: 0 }).total;

    // 脱敏手机号
    users.forEach(u => {
      if (u.phone) u.phone = u.phone.slice(0, 3) + '****' + u.phone.slice(-4);
    });

    success(res, { users, total });
  } catch (err) {
    serverError(res, err, '获取用户列表失败');
  }
}

/**
 * 封禁/解封用户
 */
async function toggleUserStatus(req, res) {
  try {
    const userId = parseInt(req.params.id, 10);
    if (isNaN(userId) || userId <= 0) {
      return error(res, 400, '用户ID无效');
    }

    const { action } = req.body;

    if (action === 'ban') {
      await executeQuery('UPDATE users SET status = 0 WHERE id = ?', [userId]);
      return success(res, null, '用户已封禁');
    } else if (action === 'unban') {
      await executeQuery('UPDATE users SET status = 1 WHERE id = ?', [userId]);
      return success(res, null, '用户已解封');
    }

    return error(res, 400, '无效操作，请使用 ban 或 unban');
  } catch (err) {
    serverError(res, err, '操作失败');
  }
}

module.exports = { getDashboard, getUserList, toggleUserStatus };
